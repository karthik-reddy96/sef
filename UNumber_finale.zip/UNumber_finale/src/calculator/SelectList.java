package calculator;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * <p>
 * Title: SelectList using a ComboBox
 * </p>
 *
 * <p>
 * Description: The main screen for a Select List exercise
 * </p>
 *
 * <p>
 * Copyright: Copyright 2016
 * </p>
 *
 * @author Lynn Robert Carter
 * @edited by karthik reddy
 * @version 1.00
 */

public class SelectList extends Application {

	// UI Section asking the user to select a Word from a Select List
	Group rootMain;
	Group rootPopUp;
	Scene sceneMain;
	Scene scenePopUp;
	
	static Stage stagePopUp;

	TitledPane t1, t2; //panes for accordion
	ObservableList<Button> arrayA = FXCollections.observableArrayList();
	ObservableList<Button> arrayB = FXCollections.observableArrayList();
	
	// UI Section asking the user to select a country from a JComboBox
	Label labelSelectAWord = new Label("Select a unit:");
	static Button btnSelectAWord = new Button("Select a unit");

	// The quit button that terminates the execution of this application
	Button buttonQuit = new Button();

	private final double WINDOW_WIDTH = 610;  	

		Button btnWord000 = createButton ("- no word selected - ", "0");
		Button btnWord001 = createButton ("m", "1");
		Button btnWord002 = createButton ("s", "2");
		Button btnWord003 = createButton ("kg", "3");
		Button btnWord004 = createButton ("amp", "4");
		Button btnWord005 = createButton ("m/s", "5");
		Button btnWord006 = createButton ("m/s^2", "6");
		Button btnWord007 = createButton ("m^2", "7");
		Button btnWord008 = createButton ("m^3", "8");

		Button btnWord047 = createButton ("ft", "47");
		Button btnWord048 = createButton ("s", "48");
		Button btnWord049 = createButton ("pound", "49");
		Button btnWord050 = createButton ("ft/s", "50");
		Button btnWord051 = createButton ("ft/s^2", "51");
		Button btnWord052 = createButton ("ft^2", "52");
		Button btnWord053 = createButton ("ft^3", "53");
		Button btnWord054 = createButton ("amp", "54");

		/**********
		 * Create a new button, set up its word, and set up the value 
		 * 
		 * @param buttonText	The text that defines the word
		 * @param txtIndex		The text that defines the word's index
		 * @return
		 */
		private Button createButton (String buttonText, String txtIndex) {
			Button button = new Button(buttonText);
			button.setOnAction(eve->{btnSelectAWord.setText(button.getText());
		    stagePopUp.close();});
			return button;
		}
		

	/*****
	 * MainScreen constructor - Establish the MainScreen as a window in the middle
	 * of the computer screen, complete with all of the various UI elements, and
	 * make it visible to the user as an interactive application window.
	 */

	private void initializeTheUserInterface() {
		// The following are the various User Interface (UI) elements on the MainScreen
		setupLabelUI(labelSelectAWord, "Arial", 18, 320, Pos.BASELINE_LEFT, 90, 80);

		setupButtonUI(btnSelectAWord, "Arial", 14, 70, Pos.BASELINE_LEFT, 200, 100);
		btnSelectAWord.setOnAction(e->{stagePopUp.showAndWait();});
		btnSelectAWord.setMinWidth(320);

		setupButtonUI(buttonQuit, "Dialog", 14, 70, Pos.BASELINE_LEFT, 500, 430);
		buttonQuit.setText("  Quit  ");
		buttonQuit.setOnAction((event) -> doQuit());
	}
	/**********
	 * Private local method to initialize the standard fields for a label
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y){
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);		
	}
	
	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e){
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);		
		t.setEditable(e);
	}
	
	/**********
	 * Private local method to initialize the standard fields for a button
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);		
	}


	/**
	 * Graphical User Interface (GUI) initialization. This sets the font and
	 * the location for each graphical element in the window, links in the
	 * action listeners, and adds all of them into the JFrame for display.
	 *
	 */
	public void start(Stage stageMain)
	{
		initializeTheUserInterface();				// Define all the GUI elements

		// The following establish the arrays of words, grouped by the first letter
		arrayA = FXCollections.observableArrayList(
				btnWord000, btnWord001, btnWord002, btnWord003, btnWord004,
				btnWord005, btnWord006, btnWord007, btnWord008);

		arrayB = FXCollections.observableArrayList(
				btnWord047, btnWord048, btnWord049, 
				btnWord050, btnWord051, btnWord052, btnWord053, btnWord054);

		rootMain = new Group();			// Create a group to hold the window UI elements
		rootPopUp = new Group();

		// This objects establish the five accordion panes
		t1 = new TitledPane("SI System", new ListView<>(arrayA));
		t2 = new TitledPane("Imperial System", new ListView<>(arrayB));

		// This method calls establishes the accordion panes and the width and height
		Accordion accordion = new Accordion();
		accordion.getPanes().addAll(t1,t2);
		accordion.setMinWidth(300);
		accordion.setMaxHeight(400);

		rootMain.getChildren().addAll(labelSelectAWord, btnSelectAWord,
				buttonQuit);
		rootPopUp.getChildren().addAll(accordion);

		sceneMain = new Scene(rootMain, WINDOW_WIDTH, 500);		// Create the scene with
		scenePopUp = new Scene(rootPopUp, 300, 400);

		stagePopUp = new Stage();
		stagePopUp.setScene(scenePopUp);
		stagePopUp.setTitle("Select a unit");

		stageMain.setTitle("KMSK Praveen");						// Label the stage (a window)
		stageMain.setScene(sceneMain);							// Set the scene on the stage
		stageMain.show();										// Show the stage to the user
	}

	/**
	 * Code to handle the "Quit" button.
	 * @param e ActionEvent
	 */
	private void doQuit() {
		System.exit(0);
	}

	/**********
	 * This mainline launches the JavaFX application.
	 * 
	 * @param args	The args are ignored
	 */
	public static void to_launch()
	{
		launch();
	}
}