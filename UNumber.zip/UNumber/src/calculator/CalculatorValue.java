package calculator;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.*;


import calculator.UNumber;


/**
 * <p> Title: CalculatorValue Class. </p>
 * 
 * <p> Description: A component of a JavaFX demonstration application that performs computations </p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2017 </p>
 * 
 * @author(baseline) Lynn Robert Carter - 
 * @author(additions) Karthik Reddy
 * 
 * @version 4.00	2017-10-18 Long integer implementation of the CalculatorValue class 
 * @version 4.10	2018-12-26 Improved the addition, subtraction, multiplication and division methods
 * 								to support UNumber.
 * @version 5.00	2018-12-26 Implemented methods of multiplication and division to handle error term.
 * @version 6.00    2018-12-26 Addition of new constructors to handle different parameters of UNumber.
 */
public class CalculatorValue {
	
	/**********************************************************************************************

	Attributes
	
	**********************************************************************************************/
	
	// These are the major values that define a calculator value
	UNumber measuredValue = new UNumber(0.0);			
	String errorMessage = "";
	UNumber zero = new UNumber(0);
	UNumber Result = new UNumber(0.0);
	
	/**********************************************************************************************

	Constructors
	
	**********************************************************************************************/

	/*****
	 * This is the default constructor with no arguments or parameters.
	 */
	public CalculatorValue() {
	}
	
	/*****
	 * This is constructor which takes the UNumber as parameter.
	 * @param unumber v
	 */
	

	public CalculatorValue(UNumber v) {
		measuredValue = v;					//The UNumber which is given to the function is stored in measured value.
	}
	
	/*****
	 * This constructor creates a calculator value based on a long integer. For future calculators, it
	 * is best to avoid using this constructor.
	 * When an errorValue is not given it makes the errorValue 0 by default.
	 */
	public CalculatorValue(double v) {			
		measuredValue = new UNumber(v);		//The double value which is given to the function is first converted to UNumber and stored in measured value.
	}
	
	/*****
	 * This constructor creates a calculator value based on a double floating point integer. For future calculators, it
	 * is best to avoid using this constructor.
	 * When both measuredValue and errorValue are given
	 */
	public CalculatorValue(double v, double e) {
		measuredValue = new UNumber(v);		//The double floating value which is given to the function is first converted to UNumber and stored in measured value.
	}
	/*****
	 * This copy constructor creates a duplicate of an already existing calculator value
	 */
	public CalculatorValue(CalculatorValue v) {
		measuredValue = v.measuredValue;		//This constructor is just a copy of before one.
		errorMessage = v.errorMessage;			//It stores measured and error value seperately.
	}
	
	/*****
	 * This constructor creates a calculator value from a string. 
	 *The input has errors, so it returns the value with the error message value set to empty or the string 
	 * of an error message.
	 * The following constructor is when no errorValue is given.
	 */
	
	public CalculatorValue(String s) {
		measuredValue = new UNumber();
		if (s.length() == 0) {								// If there is nothing there,
			errorMessage = "***Error*** Input is empty";		// signal an error	
			return;												
		}
		errorMessage= MeasuredValueRecognizer.checkMeasureValue(s);
		if(errorMessage.length()>0) {
			return;
		}		
		measuredValue = new UNumber(s);
		errorMessage = "";
	}

	/*****
	 * This constructor creates a calculator value from a string. 
	 *The input has errors, so it returns the value with the error message value set to empty or the string 
	 * of an error message.
	 * The following constructor is when
	 * both measuredValue and errorValues are given
	 */

	public CalculatorValue(String s, int i) {
		
		String mme = "";
		if(i==0)
			mme = MeasuredValueRecognizer.checkMeasureValue(s);		//Checks measure value
		else
			mme = ErrorTermRecognizer.checkErrorTerm(s);			//Checks error value
		
		measuredValue = zero;
		if (s.length() == 0) {								// If there is nothing there,
			errorMessage = "***Error*** Input is empty";		// signal an error	
			return;												
		}
		// If the first character is a plus sign, ignore it.
		int start = 0;										// Start at character position zero
		boolean negative = false;							// Assume the value is not negative
		if (s.charAt(start) == '+')							// See if the first character is '+'
			 start++;										// If so, skip it and ignore it
		
		// If the first character is a minus sign, skip over it, but remember it
		if (s.charAt(start) == '-'){					// See if the first character is '-'
			start++;											// if so, skip it
			negative = true;									// but do not ignore it
		}
		
				
		// See if the user-entered string can be converted into an integer value
		Scanner tempScanner = new Scanner(s.substring(start));// Create scanner for the digits
		
		
		if(mme.length()!=0)
		{
			if(i==0)
				errorMessage = MeasuredValueRecognizer.measuredValueErrorMessage; //if given value is 0 then error message is value of measured value recognizer.
			else
				errorMessage = ErrorTermRecognizer.errorTermErrorMessage;			//else the error message is error term recognizer. 
			tempScanner.close();
			return;
		}
		
		// Convert the user-entered string to a integer value and see if something else is following it
		String Inputnumber = tempScanner.next();				// Convert the value and check to see
		BigDecimal bg = new BigDecimal(Inputnumber);
		String StringNotation = bg.toPlainString();
		String ModifiedString = StringNotation.replace(".", "");
		measuredValue = new UNumber(ModifiedString,StringNotation.split("\\.")[0].length(),!negative,40);
		if (tempScanner.hasNext()) {							// that there is nothing else is 
			errorMessage = "***Error*** Excess data"; 		// following the value.  If so, it
			tempScanner.close();								// is an error.  Therefore we must
			measuredValue = zero;								// return a zero value.
			return;													
		}
		tempScanner.close();
		errorMessage = "";
		if (negative)										// Return the proper value based
		{
			measuredValue = new UNumber(ModifiedString,StringNotation.split("\\.")[0].length(),!negative,40);					// on the state of the flag that
		}
			
	}

	/**********************************************************************************************

	Getters and Setters
	
	**********************************************************************************************/
	
	/*****
	 * This is the start of the getters and setters
	 * 
	 * Get the error message
	 */
	public String getErrorMessage(){
		return errorMessage;
	}
	
	/*****
	 * Set the current value of a calculator value to a specific long integer
	 */
	public void setValue(long v){
		measuredValue = new UNumber(v);		//This function takes long and saves as UNumber.
	}
	
	/*****
	 * Set the current value of a calculator error message to a specific string
	 */
	public void setErrorMessage(String m){
		errorMessage = m;
	}
	
	/*****
	 * Set the current value of a calculator value to the value of another (copy)
	 */
	public void setValue(CalculatorValue v){
		measuredValue = v.measuredValue;				//This function takes UNumber and saves measured and error value separately.
		errorMessage = v.errorMessage;
	}
	
	void setPreviousValue(String x)
	{
	measuredValue.div(new UNumber(x));
	}
	
	/*Converts the measured value by multiplying with the given string x*/
	void convertMeasuredValue (String x) {			//This function takes the string and saves as UNumber.
		UNumber temp=new UNumber(x);
		measuredValue.mpy(temp);
	}	
	
	/**********************************************************************************************

	The toString() Method
	
	**********************************************************************************************/
	
	/*****
	 * This is the default toString method
	 * 
	 * When more complex calculator values are creating this routine will need to be updated
	 */
	public String toString() {
		return measuredValue + "";				//Returns the measured value as string.
	}
	public static String toString_test(String m ,String e_v) {
		
		String s = CalculatorValue.Result_toString(m , e_v);		//Takes both strings and integrates into one.	
		String lines[] = s.split("\\r?\\n");						//splits the result string when we get newline etc.
		String res = lines[1]+";"+lines[0];							
		return res;													//result is first and second index of the array.
	}
	
	/*This method converts the measured value according to the error term value*/
	public static String Result_toString(String m_v, String e_v)
	{
		
		String result = "";
		BigDecimal one = new BigDecimal(1.0);					//Decimals are taken for results.
		BigDecimal zero = new BigDecimal(0);
		BigDecimal m_value = new BigDecimal(m_v);
	
		boolean measureSign = m_value.compareTo(zero)>=0;
		m_value = m_value.abs();
	
		BigDecimal errorUpperLimit = new BigDecimal(9E3);			//Setting upper and lower limits.
		BigDecimal errorLowerLimit = new BigDecimal(1E-3);
		MathContext mc = new MathContext(1, RoundingMode.DOWN);
		BigDecimal error = new BigDecimal(e_v, mc);
		if(error.compareTo(errorUpperLimit)<0 && error.compareTo(errorLowerLimit)>0) {				//if error less than upper limit and greater than lower limit then new line is added.
			result = result + error.toPlainString()+"\n";
		}
		else {
			String dcmlfrmt = "0.";
			int lngt = 0;
			if(error.compareTo(one)>=0) {									//else just plain string is added to result and printed.
				lngt = error.toPlainString().length();
			}
			else {
				lngt = 0;
			}
			for(int i = 0;i<lngt;i++) {
				dcmlfrmt = dcmlfrmt + "0";
			}
			dcmlfrmt = dcmlfrmt + "E00";
			DecimalFormat decfor1 = new DecimalFormat(dcmlfrmt);				//The result is displayed in decimal format along with error.
			result = result + decfor1.format(error)+"\n";
		}
		
		
																				//This changes the result to the string format
		String errorString = error.toPlainString();
		BigDecimal multiplier = new BigDecimal(10);
		if(error.compareTo(one)<0) {
			if(!errorString.equals("0"))
			{
				String Character = errorString.split("\\.")[1];								
				int lngt = Character.length();
				multiplier = multiplier.pow(lngt);
				m_value = m_value.multiply(multiplier);
				m_value = new BigDecimal(m_value.toPlainString().split("\\.")[0]);
				m_value = m_value.divide(multiplier);
			}
		}
		else {
			String Character = errorString.split("\\.")[0];
			int lngt = Character.length()-1;
			multiplier = multiplier.pow(lngt);
			m_value = m_value.divide(multiplier);
			m_value = new BigDecimal(m_value.toPlainString().split("\\.")[0]);
			m_value = m_value.multiply(multiplier);
		}
		BigDecimal measureUpperLimit = new BigDecimal(1e7);
		BigDecimal measureLowerLimit = new BigDecimal(1e-5);
		if(m_value.compareTo(measureUpperLimit)<0 && m_value.compareTo(measureLowerLimit)>0) {			//upper limit and lower limit are measured.
			if(!measureSign) {
				m_value = m_value.negate();
			}
			result = result + m_value.toPlainString();
		}
		else {
			String dcmlfrmt = "0.";
			int lngt = 0;
			if(m_value.compareTo(one)>=0) {
				lngt = m_value.toPlainString().length();
			}
			else {
				int sig = 0;
				String measuredString = m_value.toPlainString();
				lngt = measuredString.length();
				for(int i=0;i<lngt;i++) {
					if((measuredString.charAt(i)!='0'&&measuredString.charAt(i)!='0')) {
						sig = i;
						break;
					}
				}
				lngt = m_value.toPlainString().substring(sig).length();
			}
			for(int i = 0;i<lngt;i++) {
				dcmlfrmt = dcmlfrmt + "0";
			}
			dcmlfrmt = dcmlfrmt + "E00";
			DecimalFormat decfor = new DecimalFormat(dcmlfrmt);
			if(!measureSign) {
				m_value = m_value.negate();
			}
			result = result + decfor.format(m_value);				//Result is changed into decimal format and shown.
		}
		return result;
	}
	
	/*****
	 * This is the debug toString method
	 * 
	 * When more complex calculator values are creating this routine will need to be updated
	 */
	public String debugToString() {
		return "measuredValue = " + measuredValue + "\nerrorMessage = " + errorMessage + "\n";
	}
	public String debugToString1() {
		return "measuredValue = " + Result + "\nerrorMessage = " + errorMessage + "\n";
	}
	public String Round_down_onesignificant(double value)
	{
		MathContext mc = new MathContext(1, RoundingMode.DOWN);
		BigDecimal bigDecimal = new BigDecimal(value, mc);
		return bigDecimal.toPlainString();										//return the output in decimal converted to string.
	}
	
	/**********************************************************************************************

	The computation methods
	
	**********************************************************************************************/
	

	/*******************************************************************************************************
	 * The following methods implement computation on the calculator values.  These routines assume that the
	 * caller has verified that things are okay for the operation to take place.  These methods understand
	 * the technical details of the values and their reputations, hiding those details from the business 
	 * logic and user interface modules.
	 * 
	 * Since this is addition,subtraction,multiplication,division and we do not yet support units, we don't recognize any errors.
	 */
	public void add(CalculatorValue v) {					//This function implements addition.
		
		Result = new UNumber(measuredValue);					
		Result.add(new UNumber(v.measuredValue));			//takes the value,adds and gives the result.
		measuredValue=Result;
		errorMessage = "";
	}

	public void sub(CalculatorValue v) {				//This function implements subtraction.
		Result = new UNumber(measuredValue);
		Result.sub(new UNumber(v.measuredValue));		//takes the value,subtracts and gives the result.
		measuredValue=Result;
		errorMessage = "";
	}

	public void mpy(CalculatorValue v) {					//This function implements multiplication.
		Result = new UNumber(this.measuredValue);
		Result.mpy(new UNumber(v.measuredValue));			//takes the value,multiplies and gives the result.
		measuredValue=Result;
		errorMessage = "";
	}
	
	public void empy(CalculatorValue v1,CalculatorValue v2,CalculatorValue ev1,CalculatorValue ev2) {				//This function implements multiplication for error values.
		if(v1.measuredValue.isZero() || v2.measuredValue.isZero())					//if value is 0, result is 0.
			measuredValue = zero;
		else
		{
			UNumber term1 = new UNumber(ev1.measuredValue);					// else takes the value,multiplies and gives the result.
			term1.mpy(v2.measuredValue);
			UNumber term2 = new UNumber(ev2.measuredValue);
			term2.mpy(v1.measuredValue);
			term1.add(term2);
			Result = new UNumber(term1);
		}
		errorMessage = "";
	}

	public void div(CalculatorValue v) {								//This function implements division.
		
		if(v.measuredValue.isZero()) {
			errorMessage = "-+++-zero division error-+++-";		//If the value is zero gives error message.
		}	
		else
		{			
			UNumber dummy = new UNumber(measuredValue);
			dummy.div(v.measuredValue);							//else takes the value,divides and gives the result.
			Result = new UNumber(dummy);
			measuredValue=Result;
			errorMessage="";
		}		
	}
	
	public void ediv(CalculatorValue v1,CalculatorValue v2,CalculatorValue ev1,CalculatorValue ev2) {				//This function implements division for errors..
		if(v2.measuredValue.isZero()) {
			errorMessage = "--zero division error--";					//If the value is zero gives error message.
		}
		else
		{
			UNumber term1 = new UNumber(ev1.measuredValue);
			term1.div(v1.measuredValue);
			UNumber term2 = new UNumber(ev2.measuredValue);				//else takes the values, divides and gives result.
			term2.div(v2.measuredValue);			
			UNumber term3 = new UNumber(v1.measuredValue);
			term3.div(v2.measuredValue);
			term1.add(term2);
			term1.mpy(term3);
			Result = new UNumber(term1);
			Result.abs();
			errorMessage="";
		}		
	}
		
	public void root() {											//This function implements square root.
		if(measuredValue.isNegative()) {
		
			errorMessage = "*-Square root of negative number gives imaginary result-Invalid Input*";		//If values are negatives prints error message.
		}
		else if(measuredValue.isPositive())
		{
			Result = UNumbersquareroot.squareRoot(measuredValue);			//Else calculates square root.
			
			errorMessage = "";
		}
		else
		{
			Result=new UNumber(0);
		}
		
	}
	
	public void er_root(CalculatorValue v1,CalculatorValue ev1) {							//This calculates square root for error value.
		if(v1.measuredValue.isNegative() || ev1.measuredValue.isNegative())
			errorMessage = "*-Square root of negative number gives imaginary result-Invalid Input*";		//If the value is zero gives error message.
		
		else if(v1.measuredValue.isPositive())
		{
			System.out.println("poitn2");
			UNumber term1 = new UNumber(ev1.measuredValue);
			term1.div(v1.measuredValue);
			term1.mpy(UNumbersquareroot.squareRoot(v1.measuredValue));				//Else calculates square root.
			term1.mpy(new UNumber(0.5));
			Result = term1;
			errorMessage = "";
		}
		else
		{
			Result=new UNumber(0);
		}
	}
}
